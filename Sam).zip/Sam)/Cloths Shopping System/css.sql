-- phpMyAdmin SQL Dump
-- version 4.9.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 12, 2020 at 01:03 PM
-- Server version: 10.4.6-MariaDB
-- PHP Version: 7.3.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `css`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE `customer` (
  `id` int(11) NOT NULL,
  `customer_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `mobile` varchar(20) NOT NULL,
  `state` varchar(30) NOT NULL,
  `city` varchar(30) NOT NULL,
  `gender` varchar(10) NOT NULL,
  `password` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`id`, `customer_name`, `email`, `address`, `mobile`, `state`, `city`, `gender`, `password`) VALUES
(1, 'Sandeep', 'sandysawarkar@gmail.com', 'Blossom Apartment, College Road, Nadiad', '9876543210', 'Gujarat', 'Surat', 'Male', 'sandy@123');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `pid` int(11) NOT NULL,
  `p_name` varchar(100) NOT NULL,
  `p_price` int(11) NOT NULL,
  `p_category` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `p_image` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`pid`, `p_name`, `p_price`, `p_category`, `description`, `p_image`) VALUES
(33, 'hjhhj', 34, 'ok', 'jkjjkjkj', 'Ma001_ch4_Oosd.docx'),
(34, 'KKKK', 45, 'ok', 'kjkj', 'EventMgmt2.pdf'),
(35, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(36, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(37, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(38, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(39, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(40, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(41, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(42, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(43, 'khkh', 4545, 'ok', 'hjhjh', 'Ch3_oosd_ma004.docx'),
(44, 'jhjh', 787, 'ok', 'jhjh', 'EventMgmt.docx'),
(45, 'jhjh', 787, 'ok', 'jhjh', 'EventMgmt.docx');

-- --------------------------------------------------------

--
-- Table structure for table `seller`
--

CREATE TABLE `seller` (
  `id` int(11) NOT NULL,
  `seller_name` varchar(50) NOT NULL,
  `business_name` varchar(50) NOT NULL,
  `email` varchar(70) NOT NULL,
  `address` varchar(100) NOT NULL,
  `state` varchar(50) NOT NULL,
  `city` varchar(50) NOT NULL,
  `product_category` varchar(50) NOT NULL,
  `mobile_no` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller`
--

INSERT INTO `seller` (`id`, `seller_name`, `business_name`, `email`, `address`, `state`, `city`, `product_category`, `mobile_no`, `password`) VALUES
(1, 'Sonu', 'Karyana', 'sonukaryana@gmail.com', 'Surat', 'Gujarat', 'Surat', 'Formals', '9913164111', 'sonu@harsh'),
(2, 'Sonu', 'Karyana', 'sonukaryana@gmail.com', 'Surat', 'Gujarat', 'Surat', 'Formals', '9913164111', 'md5(12345)'),
(3, 'Sonu', 'Karyana', 'sonukaryana@gmail.com', 'Surat', 'Gujarat', 'Surat', 'Formals', '9913164111', '96e79218965eb72c92a549dd5a330112');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customer`
--
ALTER TABLE `customer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`pid`);

--
-- Indexes for table `seller`
--
ALTER TABLE `seller`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customer`
--
ALTER TABLE `customer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `pid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `seller`
--
ALTER TABLE `seller`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

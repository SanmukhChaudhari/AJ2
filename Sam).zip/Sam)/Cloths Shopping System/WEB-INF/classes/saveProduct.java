import java.io.File;
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
import com.oreilly.servlet.MultipartRequest;


public class saveProduct extends HttpServlet {

    private final String UPLOAD_DIRECTORY = "C:/xampp/tomcat/webapps/Cloths Shopping System/upload";

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException
    {
		try
		{
            PrintWriter out = response.getWriter();
            MultipartRequest mr = new MultipartRequest(request,UPLOAD_DIRECTORY);
            response.setContentType("text/html");
            String name="";
            String temp = "";
            HttpSession session=request.getSession();



        if(ServletFileUpload.isMultipartContent(request))
        {
            try
            {

                //out.println("Name : "+nm);
                String p_name=mr.getParameter("productname");
                String p_price = mr.getParameter("productprice");
				String p_image = mr.getFilesystemName("p_image");
                String p_category=mr.getParameter("category");
                String description=mr.getParameter("description");
                String qty=mr.getParameter("qty");
                int j;
                try
                {
                    Connection con;
                    PreparedStatement pst ;
                    ResultSet rs ;
                    Class.forName("com.mysql.jdbc.Driver");
                    con=DriverManager.getConnection("jdbc:mysql://localhost:3306/css","root","");
                    //out.println(pst.toString());
                    if(true)
                    {
                      List<FileItem> multiparts = new ServletFileUpload(
                     new DiskFileItemFactory()).parseRequest(request);

                        for(FileItem item : multiparts){
                        if(!item.isFormField()){
                            name = new File(item.getName()).getName();
                            temp = new File(UPLOAD_DIRECTORY + File.separator + name).toString();
                            item.write( new File(UPLOAD_DIRECTORY + File.separator + name));
                            }
                        }
                        session.setAttribute("mes", "Product inserted Successfully");

                    pst=con.prepareStatement("insert into products(p_name, p_price, p_category, description, p_image, qty) VALUES (?,?,?,?,?,?)");
					pst.setString(1,p_name);
					pst.setString(2,p_price);
					pst.setString(3,p_category);
					pst.setString(4,description);
					pst.setString(5,p_image);
                    pst.setInt(6,Integer.parseInt(qty));
					j=pst.executeUpdate();

                    }
                    else{
                        out.println("<script>alert('some problem');</script>");
                    }
                 }
                 catch (Exception ex) {
                    out.println(ex.toString());
					    session.setAttribute("mes", "Product not inserted Successfully");

                }
            }
            catch (Exception ex) {
            out.println(ex.toString());
            request.setAttribute("message", "Connection " + ex);
           }

        }
        else
        {
			request.setAttribute("mes", "Product is not inserted Successfully");
            
            request.setAttribute("mes","Sorry this Servlet only handles file upload request");
        }
        request.getRequestDispatcher("addProduct.jsp").forward(request, response);
		}
		catch(Exception e)
		{
			//out.println(e);
		}
    }



}



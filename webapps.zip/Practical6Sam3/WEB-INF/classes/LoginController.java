import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class LoginController extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		LoginBean lb = new LoginBean();
		String nm = req.getParameter("username");
		String ps = req.getParameter("password");
		lb.setName(nm);
		lb.setPassword(ps);
		ServletContext context = getServletContext();
		String finalpass = context.getInitParameter("password");
		if(lb.getPassword().equals(finalpass))
		{
			RequestDispatcher rd = req.getRequestDispatcher("success.jsp");
			rd.forward(req,res);
		}
		else
		{
			RequestDispatcher rd = req.getRequestDispatcher("error.jsp");
			rd.forward(req,res);
		}
	}
}
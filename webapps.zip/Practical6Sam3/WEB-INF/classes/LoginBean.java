public class LoginBean
{
	private String name,password;
	void setName(String name)
	{
		this.name = name;
	}
	void setPassword(String password)
	{
		this.password = password;
	}
	String getName()
	{
		return name;
	}
	String getPassword()
	{
		return password;
	}
}
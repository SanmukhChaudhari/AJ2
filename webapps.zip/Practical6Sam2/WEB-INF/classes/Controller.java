import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class Controller extends HttpServlet
{
	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		MyBean lb = new MyBean();
		String exp = req.getParameter("exp");
		char e[] = exp.toCharArray();
		int past_p=0,p=0;
		MyBean mb = new MyBean();

		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		for(int i = 0; i<e.length;i++)
		{
			if(e[i] == '+' || e[i] == '-' || e[i] == '*' || e[i] == '/' || e[i] == '%')
			{
				String par = exp.substring(past_p,i);
				String op = exp.substring(i,i+p);
				past_p=i+1;

				if(p==0){mb.setA(par);mb.setFop(op);}
				if(p==1){mb.setB(par);mb.setSop(op);}
				if(p==2){mb.setC(par);}
				out.println("<body>"+par+" : "+op+"</body>");
				p++;
				i++;
			}
		}
		int ans = lb.getResult();
		out.println("<body>"+ans+"</body>");
	}
}
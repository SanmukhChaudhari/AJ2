public class MyBean
{
	private int a,b,c;
	private String fop,sop;
	void setA(String a)
	{
		this.a = Integer.parseInt(a);
	}
	void setB(String b)
	{
		this.b = Integer.parseInt(b);
	}
	void setC(String c)
	{
		this.c = Integer.parseInt(c);
	}
	int getA()
	{
		return a;
	}
	int getB()
	{
		return b;
	}
	int getC()
	{
		return c;
	}
	void setFop(String op){this.fop = op;}
	void setSop(String op){this.sop = op;}
	int getResult()
	{
		int fans=0,sans=0;
		if(fop == "+"){fans = a + b;}
		if(fop == "-"){fans = a - b;}
		if(fop == "*"){fans = a * b;}
		if(fop == "/"){fans = a / b;}
		if(fop == "%"){fans = a % b;}

		if(sop == "+"){sans = fans + c;}
		if(sop == "-"){sans = fans - c;}
		if(sop == "*"){sans = fans * c;}
		if(sop == "/"){sans = fans / c;}
		if(sop == "%"){sans = fans % c;}
		return sans;
	}

}
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FirstServlet extends HttpServlet
{
	int c = 1;
	public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String uname = request.getParameter("username");
		Cookie ck = new Cookie("count",c+"");
		String cook = ck.getValue();
		c++;
		ck.setValue(c+"");
		out.println("Hello "+uname+" Visited : "+cook);
	}
}
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class SecondServlet extends HttpServlet
{
	int c;
	public void service(HttpServletRequest request,HttpServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String count = request.getParameter("count");
		c = Integer.parseInt(count);
		c++;
		out.println("Hello "+c+" Visited : ");
		response.setIntHeader("Refresh",1);

	}
}
import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

public class FirstServlet extends HttpServlet
{

	public void doGet(HttpServletRequest req,HttpServletResponse res) throws ServletException,IOException
	{
		ServletConfig conf = getServletConfig();
		res.setContentType("text/html");
		PrintWriter out = res.getWriter();
		String name = conf.getInitParameter("colorname");
		out.println("<body style='background-color:"+name+"'></body>");
	}
}